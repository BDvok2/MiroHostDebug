<?php

include_once TECHLINK_CORE_CPT_PATH . '/clients/shortcodes/clients-list/variations/image-only/image-only.php';
include_once TECHLINK_CORE_CPT_PATH . '/clients/shortcodes/clients-list/variations/image-only/hover-animations/include.php';